import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from matplotlib.backends.backend_pdf import PdfPages

# ✅ Save the PDF in your Windows Downloads folder
pdf = PdfPages("C:/Users/ASUS/Downloads/sales_summary_output.pdf")

# Load dataset
df = pd.read_csv("C:/Users/ASUS/Downloads/Advertising.csv")

# Drop unnecessary column
df = df.drop(columns=['Unnamed: 0'])

# Buffer to hold text
buffer = []
buffer.append("Sales Prediction Summary\n")
buffer.append("="*30 + "\n")

# Add DataFrame info
buffer.append("DataFrame Info:\n")
buffer.append(str(df.info()))
buffer.append("\nFirst 5 rows:\n")
buffer.append(df.head().to_string())

# Pairplot
sns.pairplot(df, x_vars=['TV', 'Radio', 'Newspaper'], y_vars='Sales', height=4, aspect=1, kind='scatter')
plt.suptitle("Pairplot of Features vs Sales", y=1.02)
pdf.savefig()
plt.close()

# Correlation heatmap
plt.figure(figsize=(6, 4))
sns.heatmap(df.corr(), annot=True, cmap='coolwarm')
plt.title("Correlation Heatmap")
pdf.savefig()
plt.close()

# Features and target
X = df[['TV', 'Radio', 'Newspaper']]
y = df['Sales']

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = LinearRegression()
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

# Evaluation
r2 = r2_score(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)

# Model summary
buffer.append(f"\nModel Intercept: {model.intercept_}")
buffer.append("\nModel Coefficients:")
for feature, coef in zip(X.columns, model.coef_):
    buffer.append(f"  {feature}: {coef}")

buffer.append(f"\nR2 Score: {r2:.4f}")
buffer.append(f"Mean Squared Error: {mse:.4f}")

# Prediction example
new_data = pd.DataFrame({'TV': [150], 'Radio': [25], 'Newspaper': [20]})
predicted_sales = model.predict(new_data)[0]
buffer.append(f"\nPredicted Sales for TV=150, Radio=25, Newspaper=20: {predicted_sales:.2f}")

# Save text to PDF
plt.figure(figsize=(8.5, 11))
plt.axis('off')
plt.text(0, 1, "\n".join(buffer), fontsize=10, va='top')
pdf.savefig()
plt.close()

# Save and close the PDF
pdf.close()
